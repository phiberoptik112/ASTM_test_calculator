#chapt 12 assignment 5

# To run this, download the BeautifulSoup zip file
# http://www.py4e.com/code3/bs4.zip
# and unzip it in the same directory as this file
# MUST BE RUN IN PYTHON 3
import urllib.request, urllib.parse, urllib.error
from bs4 import BeautifulSoup
import ssl
import re
count = 0 # count down the number of entries
followdlinks = 0
# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
#url = input('Enter - ')
#url = "http://py4e-data.dr-chuck.net/known_by_Fikret.html"
url = "http://py4e-data.dr-chuck.net/known_by_Aleeyah.html"
html = urllib.request.urlopen(url, context=ctx).read()
soup = BeautifulSoup(html, 'html.parser')
tags = soup('a')

while followdlinks <= 7 : #4
    for tag in tags:
        print(tag)
    #link = re.findall('http.+?.l',tag.decode())
        count = count + 1
        #print(count)
        if count == 18: #3
            link = re.findall('http.+?.l',tag.decode())
            #print(link[0])
            name = re.findall('>(.+)</',tag.decode())
            print(name)
            newhtml = urllib.request.urlopen(link[0], context=ctx).read()
            newsoup = BeautifulSoup(newhtml, 'html.parser')
            print("opened link", link[0])
            tags = newsoup('a')
            followdlinks = followdlinks + 1
            print(followdlinks)
            print(tags[18])
            count = 0
            print("resetting count")
            break
