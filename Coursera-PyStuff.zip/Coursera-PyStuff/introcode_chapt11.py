# Chapt 11 intro screenshots
#print("these screenshots are making me thirsty")
# some quick code comparing with regular expressions
import re
hand = open("mbox-short.txt")
for line in hand:
    line = line.rstrip()
    if re.search('^From:', line):
        print(line)
# this, versus the old code using .startswith
# the carrot character is the wildcard char that has additional logic
