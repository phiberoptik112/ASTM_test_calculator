#assignment 8 pt 5
#fname = input("Enter file name: ")
fh = open("mbox-short.txt")
#if len(fname) < 1 : fname = "mbox-short.txt"
lst = list()
unsorted = list()
#fh = open(fname)
count = 0
for line in fh:
    if not line.startswith("From "): continue
    toparse = line.split()
    unsorted.append(toparse[1])
    print(toparse[1])
#targetcount = toparse.count(target)
    count = count+1


print("There were", count, "lines in the file with From as the first word")
