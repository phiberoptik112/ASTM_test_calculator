# assignment 3.3
score = input("Enter Score: ")

try:
    usrscor = float(score)
except:
    print("Error, bad user input")
    quit()
if usrscor > 1.0 :
    print("Error, value must be within 0 - 1.0")
elif usrscor < 0 :
    print("Error, value must be within 0 - 1.0")
else :
    if usrscor >= 0.9 : print("A")
    elif usrscor >= 0.8 : print("B")
    elif usrscor >= 0.7 : print("C")
    elif usrscor >= 0.6 : print("D")
    elif usrscor < 0.6 : print("F")
