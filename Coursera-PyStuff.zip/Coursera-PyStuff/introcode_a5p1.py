# chapt 5 assignment
# this code functions in the class grader, but not
# when running it, it produces an endless loop with the
# while loop in place like it is
largest = None
smallest = None
#while True:
try:
    num = input("Enter a number: ")
    if num == "done" : break
    numf = int(num)
except:
    print("Invalid input")
    continue
if smallest is None :
    smallest = numf
if largest is None :
    largest = numf
elif smallest > numf :
    smallest = numf
elif largest < numf :
    largest = numf

print("Maximum is", largest)
print("Minimum is", smallest)
