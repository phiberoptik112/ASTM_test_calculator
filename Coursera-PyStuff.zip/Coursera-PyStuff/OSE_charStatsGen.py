#OSDnd character sheet generator
import random
#3d6 for 6 ability scores

abilities = ['str', 'int', 'wis','dex','con','charis']

for rolls in abilities:
    rollone = random.randint(1, 6)
    rolltwo = random.randint(1, 6)
    rollthree = random.randint(1, 6)
    total = rollone+rolltwo+rollthree
    print('Stat roll:', rolls)
    print(total)


rollone = random.randint(1, 6)
rolltwo = random.randint(1, 6)
rollthree = random.randint(1, 6)
threeDsix = rollone+rolltwo+rollthree
gold_amount = threeDsix*10
print('Gold:', gold_amount)

theif_hitdie = random.randint(1,4)
print('Theif, magic user hit die:',theif_hitdie)

cleric_hitdie = random.randint(1,6)
print('cleric, elf, halfling hit die:',cleric_hitdie)

fighter_hitdie = random.randint(1,8)
print('Fighter, dwarf hit die:',fighter_hitdie)
