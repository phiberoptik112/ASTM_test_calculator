#Pycourse 2: Webdata handling - needle in haystack
fh = open("regex_sum_391137.txt")
import re
num = None
intsum = 0
lotsnum = list()
for line in fh:
    line = line.rstrip()
    if re.search('[0-9]+', line):
        num = re.findall('[0-9]+',line)
        for i in num :
            intsum = intsum + int(i)

print(intsum)
