# chapt 10 assignment 2
#name = input("Enter file:")
#if len(name) < 1 : name = "mbox-short.txt"
handle = open("mbox-short.txt")
lst = list()
sendtime = list()
for line in handle:
    if not line.startswith("From "): continue
    toparse = line.split()
    sendtime = toparse[5]
    #print(sendtime)
    timeparsed = sendtime.split(':')
    lst.append(timeparsed[0])

histo = dict()
tmp = list()
for time in lst:
    histo[time] = histo.get(time, 0)+1
#tmp = sorted(histo.items())
#print(tmp)
# at this point, the output is correct from tmp, it just has the
#attchments of the tuple[',']. the output apparently needs
# new line chars \n between each entry, with no extra attchments

for time, count in sorted(histo.items()):
    print(time, count)
