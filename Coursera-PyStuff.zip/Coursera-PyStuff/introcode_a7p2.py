# chapt 7 assignment 2
# Use the file name mbox-short.txt as the file name
avgnums = None
filecount = None

fname = input("Enter file name: ")
fh = open(fname)
for line in fh:
    if not line.startswith("X-DSPAM-Confidence:") : continue
    if filecount is None :
        filecount = 1
    else :
        filecount = filecount + 1
    santext = line.strip()
    newinpos = line.find(':')
    #print(line)
    extract = line[newinpos+1:]
    if avgnums is None :
        avgnums = float(extract)
        #print(avgnums)
    else :
        avgnums = avgnums + float(extract)
    #print(avgnums)
#print("Done, dividing by number of entries")
avgspam = float(avgnums/filecount)

print("Average spam confidence:", float(avgspam))
