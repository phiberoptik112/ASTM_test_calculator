from tkinter import *
# import pandas as pd #import pandas

# root wiget
root = Tk()

#  basic text entry box
entrybox = Entry(root).pack()

# plan is to write to CSV, then read back
username = Entry(root).grid(row=1, column=0)
Fit_session = Entry(root).grid(row=1, column=0)
Fit_number = Entry(root).pack()
Calibration_date = Entry(root).pack()

#function to print to screen when clicked
def myClick():
        myLabel = Label(root, text= "look, i clicked it!")
        # print to screen
        myLabel.pack()

# creating label wiget - just write to screen
myLabel1 = Label(root, text="First button!").pack()

# remember, the command for buttons does NOT need () - will not run
mybutton = Button(root, text="click it!", command=myClick).pack()
#pushed to screen without order
# mybutton.pack()
# now with organization - all relative to each entry
# myLabel.grid(row=0, column=0)

# creating event loop
root.mainloop()
