# chapt 4 assignment
def computepay(h,r):
    if h > 40 :
        ovrtime = h-40
        addpay = ovrtime*(r*1.5)
        grosspay = addpay + 40*r
    else :
        grosspay = h*r
    return grosspay

hrs = input("Enter Hours:")
rate = input("Enter rate:")
try:
    h = float(hrs)
    r = float(rate)
except:
    print("Error, bad user input")
    quit()

p = computepay(h,r)
print("Pay",p)
