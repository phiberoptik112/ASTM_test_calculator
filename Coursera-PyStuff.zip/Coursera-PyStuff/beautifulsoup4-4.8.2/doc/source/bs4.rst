bs4 package
===========

Subpackages
-----------

.. toctree::

    bs4.builder

Submodules
----------

bs4.dammit module
-----------------

.. automodule:: bs4.dammit
    :members:
    :undoc-members:
    :show-inheritance:

bs4.diagnose module
-------------------

.. automodule:: bs4.diagnose
    :members:
    :undoc-members:
    :show-inheritance:

bs4.element module
------------------

.. automodule:: bs4.element
    :members:
    :undoc-members:
    :show-inheritance:

bs4.formatter module
--------------------

.. automodule:: bs4.formatter
    :members:
    :undoc-members:
    :show-inheritance:

bs4.testing module
------------------

.. automodule:: bs4.testing
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: bs4
    :members:
    :undoc-members:
    :show-inheritance:
