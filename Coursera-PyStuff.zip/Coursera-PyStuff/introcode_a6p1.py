# chapt 6 assignment 1
text = "X-DSPAM-Confidence:    0.8475";
santext = text.strip()
newinpos = text.find(':')
endpos = text.find('5')
#print(newinpos)
extract = text[newinpos+1:endpos]
print(float(extract))

#
