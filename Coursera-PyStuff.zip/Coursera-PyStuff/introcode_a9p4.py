#assignment 9 chapt 4
#name = input("Enter file:")
#if len(name) < 1 : name = "mbox-short.txt"

handle = open("mbox-short.txt")
histo = dict()
unsorted = list()

for line in handle:
    if not line.startswith("From "): continue
    toparse = line.split()
    unsorted.append(toparse[1])
    #print(unsorted)
for name in unsorted :
    histo[name] = histo.get(name, 0)+1
# idium: retreive/create/update counter
#print(histo)
maxval = None
maxsendr = None
for addr,numsend in histo.items():
    #print(numsend)
    #print(addr)
    if maxval is None or numsend > maxval:
        maxsendr = addr
        maxval = numsend

print(maxsendr,maxval)
