# audio file fun with PYTHON
import matplotlib.pyplot as plt
import pylab
import numpy as np
import wave, os, audioop, struct,io
import soundfile as sf
import scipy as sp
from scipy.io import wavfile as wave
from pathlib import Path
import pandas as pd
import sys
from bokeh.plotting import figure
from bokeh.io import output_notebook, show

# read files to plot, store in something that makes sens
# dict? is that right in python? check rea
