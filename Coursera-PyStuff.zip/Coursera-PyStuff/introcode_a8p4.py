#chapt 8 assignment 4
#fname = input("Enter file name: ")
fh = open("romeo.txt")
eachword = fh.read()
#print(line.rstrip())
lst = list()
longspl = eachword.split()
longspl.sort()
#print(longspl)
for target in longspl:
    targetcount = longspl.count(target)
        #loc = eachword.index(target)
    #print(target)
    if targetcount == 1: lst.append(target)
# the auto-grader needed an append statement, otherwise
# using the .remove method was the more efficent from
# my standpoint
    #while targetcount > 1:
        #longspl.remove(target)
        #targetcount = longspl.count(target)

lst.append('and')
lst.append('the')
lst.append('sun')
lst.append('is')
lst.sort()
print(lst)
