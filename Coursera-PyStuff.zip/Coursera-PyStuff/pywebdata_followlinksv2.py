#chapt 12 assignment 5
# To run this, download the BeautifulSoup zip file
# http://www.py4e.com/code3/bs4.zip
# and unzip it in the same directory as this file
# MUST BE RUN IN PYTHON 3
import urllib.request, urllib.parse, urllib.error
from bs4 import BeautifulSoup
import ssl
link = input("Enter url: ")
followdlinks = input("Enter count: ")
count = input("Enter position: ")
# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
while int(followdlinks) > 0:
    newhtml = urllib.request.urlopen(link, context=ctx).read()
    newsoup = BeautifulSoup(newhtml, 'html.parser')
    tags = newsoup('a')
    link = tags[int(count)-1].get('href')
    print("ended on:", link)
    followdlinks = int(followdlinks) -1
