# chapt 7 assignment 1
# Use words.txt as the file name
fname = input("Enter file name: ")
fh = open(fname)
for line in fh :
    line = line.rstrip()
    #capsline = line.upper()
    print(line.upper())
